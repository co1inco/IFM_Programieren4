"""
-----------------------------------------------------------------------------
Vorlesung: Bildverarbeitung und Mustererkennung (Sommersemseter 2026)
Thema: Aufgabenzettel 1
-----------------------------------------------------------------------------
"""

# nur die in den allgemeinen Richtlinien gegebenen Methoden dürfen verwendet werden - im Zweifel nachfragen.
import numpy as np
# nur die bereits im Code vorhandenen OpenCV-Methoden dürfen verwendet werden
import cv2
# für das Anzeigen des 1D Histogramms
from matplotlib import pyplot as plt



# Bild laden
image_color = cv2.imread('fahrbahn.jpg')
# Konvertierung in ein Grauwertbild
image_gray = cv2.cvtColor(image_color, cv2.COLOR_BGR2GRAY)
# weitere Methoden, die verwendet werden können
#image_tmp = image_gray.copy();
#rows,cols = image_gray.shape


# Bild anzeigen
cv2.imshow("Bild", image_color)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Bild speichern
#cv2.imwrite("output.jpg", image_gray)


# ------------------------------------------------------------------------
# (a) 1D Histogramm
# ------------------------------------------------------------------------
# 1. Implementieren Sie die Methode
# histogram = computeHistogram(image_gray)
# 2. Visualisieren Sie Ihr Ergebnis


# ------------------------------------------------------------------------
# (b) 2D Histogramm
# ------------------------------------------------------------------------
# 1. Implementieren Sie die Methode
# histogram2D = computeHistogram2D(image_color)
# 2. Visualisieren Sie Ihr Ergebnis


# ------------------------------------------------------------------------
# (c) Segmentierung
# ------------------------------------------------------------------------
# 1. Implementieren Sie die Methode
# segmentierung(histogram2D)
#  * Nutzen Sie für die Auswahl der Region im 2D Histogramm folgende OpenCV-Funktion: region=cv2.selectROI(histogram2D)
#  * Visualisieren Sie das Segmentierungsergebnis
